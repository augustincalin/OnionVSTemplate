﻿namespace $safeprojectname$.Common
{
    public abstract class Entity
    {
        public int Id { get; set; }
    }
}
