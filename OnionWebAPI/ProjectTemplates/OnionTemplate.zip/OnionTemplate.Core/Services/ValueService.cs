﻿using $safeprojectname$.Interfaces;
using $safeprojectname$.Model;

namespace $safeprojectname$.Services
{
    public class ValueService : IValueService
    {
        private readonly IRepository<Value> _valueRepository;

        public ValueService(IRepository<Value> valueRepository)
        {
            _valueRepository = valueRepository;
        }

        public async Task<Value> GetAValue(int id)
        {
            return await _valueRepository.GetAsync(id);
        }
    }
}
