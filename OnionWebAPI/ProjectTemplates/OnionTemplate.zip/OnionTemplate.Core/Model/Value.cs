﻿using $safeprojectname$.Common;

namespace $safeprojectname$.Model
{
    public class Value: Entity
    {
        public string? Name { get; set; }
        public string? Description { get; set; }
    }
}
