﻿using $safeprojectname$.Model;

namespace $safeprojectname$.Interfaces
{
    public interface IValueService
    {
        Task<Value> GetAValue(int id);
    }
}
