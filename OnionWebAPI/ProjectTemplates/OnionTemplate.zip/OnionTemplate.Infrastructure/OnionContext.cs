﻿using Microsoft.EntityFrameworkCore;
using $ext_safeprojectname$.Core.Model;

namespace $safeprojectname$
{
    /*
     * You would want to generate the model from an existing database via scaffolding.
     * Then move the entities into $ext_safeprojectname$.Core project and keep here the DbContext.
     * See https://docs.microsoft.com/en-us/ef/core/managing-schemas/scaffolding?tabs=dotnet-core-cli
     */
    public class OnionContext : DbContext
    {
        public OnionContext(DbContextOptions<OnionContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Value> Values { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Value>(entity => { entity.ToTable("Values"); });
        }
    }
}
